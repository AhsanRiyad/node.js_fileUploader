<!-- <?php echo e(dump($feature_image[0])); ?> -->
<div id="categoryProductView">
    <div class="categoryProduct">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4 col-sm-12 col-xs-12 nopadding">
                    <div class="productimageBox">
                        <a href="/games/<?php echo e($game[0]->slug); ?>">
                        <h3 style="color:white; font-size:30px;line-height:50px;white-space:nowrap;text-overflow:ellipsis;"><?php echo e($game[0]->title); ?></h3>
                            <div class="productimageBoxInner">

                                <div class="unskew-reverseHomepage">
                                    <img class="img-responsive"  src="<?php echo e($feature_image[0]); ?>" />
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12 nopadding">
                    <div class="productimageBox2">
                       <a href="/games/<?php echo e($game[1]->slug); ?>">
                        <h3 style="color:white; font-size:30px;line-height:50px;white-space:nowrap;text-overflow:ellipsis;"><?php echo e($game[1]->title); ?></h3>
                            <div class="productimageBoxInner">
                                <div class="unskew-reverseHomepage">

                                    <img class="img-responsive" src="<?php echo e($feature_image[1]); ?>" />
                                </div>
                            </div>
                       </a>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12 nopadding">
                    <div class="productimageBox3">
                        <a href="/games/<?php echo e($game[2]->slug); ?>">
                        <h3 style="color:white; font-size:30px;line-height:50px;white-space:nowrap;text-overflow:ellipsis;"><?php echo e($game[2]->title); ?></h3>
                            <div class="productimageBoxInner">
                                <div class="unskew-reverseHomepage">

                                    <img class="img-responsive"  src="<?php echo e($feature_image[2]); ?>" />
                                </div>
                            </div>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>


<!--===================== Begin:categoryProductView Mobile======================== -->
<!-- <div class="categoryProductViewMobiles">
			<div class="productBoxs">
				<div class="box1">
					<div class="innerImagebox">
						<img class="img-responsive" src="<?php echo e(asset('home_template/images/product/latest-game3.png')); ?>">
					</div>
				 </div>
				<div class="boxlavel2">
					<div class="box2">
						<div class="innerImagebox">
						  <img class="img-responsive" src="<?php echo e(asset('home_template/images/product/latest-game3.png')); ?>">
						</div>
					</div>
					<div class="box3">
						<div class="innerImagebox">
							<img class="img-responsive" src="<?php echo e(asset('home_template/images/product/latest-game3.png')); ?>">
						</div>
					</div>
				</div>

			</div>
        </div> -->


























<!--===================categoryMenu=====================-->

<div class="categoryMenu">
    <div class="categorymenuInner">
        <ul>
            <li><a href="/products/category/1">CLOTHING</a></li>
            <li><a href="/products/category/2">ACCESSORIES</a></li>
            <li><a href="/products/category/3">COLLECTIBLES</a></li>
            <li class="viewShop"><a href="/shops">VIEW SHOP</a></li>
        </ul>
    </div>
</div>
<?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/category.blade.php ENDPATH**/ ?>