<!--================ Slider div :Begin ===================-->

<div class="hero_carosel owl-carousel owl-theme owl-loaded owl-drag">
    <?php
        $loopIndex = 0;
    ?>
<?php $__currentLoopData = $game; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="hero-item">
        <div class="hero-img">
            <div class="overlayerBg">
                <?php if($gm->status == 1): ?>
                    <img src="<?php echo e(url($gm->banner)); ?>" alt="">
                <?php elseif(($gm->status == 3)): ?>
                    <img src="https://soundleisure.com/uploads/backgrounds/Background_Image_2.jpg" alt="">
                <?php endif; ?>

            </div>
        </div>

        <div class="banner-details">
            <div class="container">
                <div class="row display_flex">
                    <div class="col-md-6 col-sm-8">
                        <div class="desc">
                            <h2><?php echo e($gm->title); ?></h2>
                            <div class="ag-center">
                                <p class="carsl_btn"><a href="games/<?php echo e($gm->slug); ?>" class="btn-gradient-bg">View Game </a></p>
                                <p class="carsl_btn ml"><a href="<?php echo e($gm->trailer); ?>" target="_blank" class="btn-gradient-bg">Game Trailer </a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="side-img">
                            <img class="img-responsive" src="<?php echo e(($feature_image[$loopIndex])); ?>" alt="">
                        </div>
                    </div>
                    <div class="col-md-2">
                    </div>
                </div>
            </div>
        </div>
    </div>
       <?php

        $loopIndex = $loopIndex + 1;
        ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<!--================= Slider div :End ===================-->



<div class="bannerBottomMenuSection">
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="latestGame">
                <h3><a href="#">Latest Products</a></h3>
            </div>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-6">
            <div class="viewAllGame">
                <h3><a href="/games">View All</a></h3>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/banner.blade.php ENDPATH**/ ?>