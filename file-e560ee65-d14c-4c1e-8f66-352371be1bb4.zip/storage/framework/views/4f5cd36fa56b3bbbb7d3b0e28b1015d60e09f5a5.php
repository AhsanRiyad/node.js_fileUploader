

        <!--JQUERY.MIN.JS-->

        <script src="<?php echo e(asset('home_template/assets/js/jquery.min.js')); ?>" type="text/javascript"></script>

        <!-- Include all compiled plugins (below), or include individual files as needed -->

        <!-- WAYPOINTS -->

        <script src="<?php echo e(asset('home_template/assets/js/waypoints.min.js')); ?>" type="text/javascript"></script>

        <!--BOOTSTRAP-->

        <script src="<?php echo e(asset('home_template/assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

        <!--OWL.CAROUSEL.MIN.JS-->


        <script src="<?php echo e(asset('home_template/assets/js/owl.carousel.min.js')); ?>" type="text/javascript"></script>

        <!--WOW.MIN.JS-->

        <script src="<?php echo e(asset('home_template/assets/js/wow.min.js')); ?>" type="text/javascript"></script>


        <script src="<?php echo e(asset('home_template/assets/js/plugin.js')); ?>" type="text/javascript"></script>		
        <script src="<?php echo e(asset('home_template/assets/js/custom.js')); ?>" type="text/javascript"></script>

        <script>
        //Get the button
        var mybutton = document.getElementById("myBtn");

        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};

        function scrollFunction() {
          if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
          } else {
            mybutton.style.display = "none";
          }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
          document.body.scrollTop = 0;
          document.documentElement.scrollTop = 0;
        }
        </script>
    </body>
</html>
<?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/footerbtm.blade.php ENDPATH**/ ?>