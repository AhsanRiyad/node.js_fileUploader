

<?php echo $__env->make('publicuser.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<header id="header">
    <div class="headerTop">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-xs-6">
                    <div class="TopSocialIcon">
                        <ul>
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-4">
                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="loginbtn">
                        <h3>Login</h3>
                    </div>
                </div>

            </div>
        </div>
    </div>

</header>
<!--Header End-->


<div class="headerInnerSetion">
    <div class="headerBottom">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-4">
                    <div class="logo">
                        <a href="./"><img class="img-responsive" src="<?php echo e(asset('home_template/images/logo.png')); ?>" ></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--==================Main Menu :Begin====================-->


    <nav class="navbar navbar-expand-lg navbar-light">
        <div id="mainmenu">
            <div class="menu-section">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-4 col-sm-2 col-md-2 col-lg-2">
                            <div class="otherpagelogo collapse-logo">
                                <a href="/../"><img class="img-responsive"
                                                    src="<?php echo e(asset('home_template/images/logo.png')); ?>"></a>
                            </div>
                        </div>
                        <div class="col-md-12 col-xs-8 col-sm-10">
                            <div class="mainmenuSection mainmenuhomePage">
                                <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon" style="color: #fff; font-size: 30px;"><i class="fa fa-bars"></i></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <div class="mainmenu">
                                        <ul class="navbar-nav">
                                            <li class="nav-item active">
                                                <a class="nav-link" href="/games">GAMES <span class="sr-only">(current)</span></a>
                                            </li>
                                            <li class="nav-item ">
                                                <a class="nav-link dropdown-toggle" href="/shops">
                                                    SHOP
                                                </a>

                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="/pages/stern-insider">STERN INSIDER</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="/pages/news">NEWS</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="/pages/stern-army">STERN ARMY</a>
                                            </li>

                                            <li class="nav-item">
                                                <a class="nav-link" href="/pages/support">SUPPORT</a>
                                            </li>

                                        </ul>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </nav>
</div>
<div style="width:100vw; min-height:50vh;background:white;color:red;top:300px;text-align:center; padding:17% 0">
    <h2>Somethings wrong,Page not found</h2>
</div>




<!--Footer Start-->
<?php echo $__env->make('publicuser.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--footer_copyright-->
<?php echo $__env->make('publicuser.footerbtm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\laravel\sec\sec\resources\views/errors/404.blade.php ENDPATH**/ ?>