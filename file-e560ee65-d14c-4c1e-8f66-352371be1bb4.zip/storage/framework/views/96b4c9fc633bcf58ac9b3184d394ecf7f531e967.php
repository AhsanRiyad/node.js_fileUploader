<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- META DATA -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!-- TITLE OF SITE -->
        <title>SHAINYOU ENT CO. LTD</title>

        <!-- GOOGLE FONTS-->
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;500;600;700&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700,700i,800" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Raleway:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
        <!-- FAVICON -->
        <!-- <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon"> -->

        <!--FONT-AWESOME.MIN.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
        <link  href="<?php echo e(asset('home_template/assets/css/font-awesome.css')); ?>" rel="stylesheet">



        <!--ANIMATE.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/animate.css')); ?>" rel="stylesheet">

        <!--OWL.CAROUSEL.MIN.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/owl.carousel.min.css')); ?>" rel="stylesheet">

        <!--JQUERY-UI.MIN.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/jquery-ui.min.css')); ?>" rel="stylesheet">

        <!--LIGHTBOX.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/lightbox.css')); ?>" rel="stylesheet">

        <!--SLIDER REVOLUTION CSS SETTINGS -->

        <!-- <link  href="<?php echo e(asset('home_template/rs-plugin/css/layers.css')); ?>" rel="stylesheet">

        <link  href="<?php echo e(asset('home_template/rs-plugin/css/settings.css')); ?>" rel="stylesheet"> -->

        <!--BOOTSTRAP.MIN.CSS AND BOOTSNAV.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!--STYLE.CSS-->

        <!-- <link  href="<?php echo e(asset('home_template/assets/css/style.css')); ?>" rel="stylesheet"> -->
        <link  href="<?php echo e(asset('css/home-style.css')); ?>" rel="stylesheet">

        <!--RESPONSIVE.CSS-->

        <link  href="<?php echo e(asset('home_template/assets/css/responsive.css')); ?>" rel="stylesheet">


    </head>
    <body><?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/header.blade.php ENDPATH**/ ?>