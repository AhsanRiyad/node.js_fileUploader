<section id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="footer_sngl">
                    <h3 class="footer_title">Store information</h3>
                    <ul>
                        <li> <a href="/pages/about-us">About us</a></li>
                        <li> <a href="/pages/shipping-instructions">Shipping instructions</a></li>
                        <li> <a href="/pages/warranty-and-installation">Warranty and installation</a></li>
                        <li> <a href="/pages/privacty-statement">Privacy Statement</a></li>
                    </ul>
                </div><!--footer_sngl-->
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="footer_sngl">
                    <h3 class="footer_title">Customer service</h3>
                    <ul>
                        <li><a href="#" target="_blank">Contact us</a> </li>
                        <li><a href="/pages/an-overview-of-the-site" target="_blank">An overview of the site</a> </li>
                    </ul>
                </div><!--footer_sngl-->
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="footer_sngl">
                    <h3 class="footer_title">Other services</h3>
                    <ul>
                        <li><a href="/pages/brand-overview">Brand overview</a></li>
                    </ul>
                </div><!--footer_sngl-->
            </div>
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="footer_sngl">
                    <h3 class="footer_title">Member Center</h3>
                    <ul>
                        <li> <a href="/member-center">Member Center</a></li>
                    </ul>
                </div><!--footer_sngl-->
            </div>
        </div>
    </div><!--footerTop-->
</section>
<!--Footer End-->
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>


<div class="footer_copyright">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="copyright_sngl">
                    <p>© Sec 2020 All Rights Reserved. Powered By <a href="http://portland.tech/" target="_blank">Portland.tech</a> </p>
                </div><!--copyright_sngl-->
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/footer.blade.php ENDPATH**/ ?>