<!----=================== REPRESENT SEC ==================---->
<section id="representsec">
    <div class="row">
        <div class="col-md-6 col-sm-6 col-xs-12">
            <h4><img class="img-responsive"  src="<?php echo e(asset('home_template/images/represent.jpg')); ?>" /></h4>
        </div>
        <div class="col-md-6 col-sm-6 col-xs-12">
            <div class="representsecbox">
                <h3>REPRESENT</h3>
                <h4><img class="img-responsive"  src="<?php echo e(asset('home_template/images/secicon.jpg')); ?>"></h4>
                <h5><a class="viewTrailer" href="">View Trailer</a></h5>
            </div>
        </div>
    </div>
</section>




<div id="portfolio" class="client">
    <div class="container-fluid">
        <div class="clients_slider owl-carousel owl-theme">

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="item client_logos">
                    <div class="productImage client_img">
                        <img class="img-responsive image" src="<?php echo e($product->banner); ?>">
                        <div class="overlay">
                            <div class="text">
                                <a href="/games/<?php echo e($product->slug); ?>">Details</a>
                            </div>
                        </div>

                    </div>
                    <div class="productTitle">
                        <a href="/games/<?php echo e($product->slug); ?>"><h3><?php echo e($product->title); ?></h3></a>
                    </div>
                    <!--<div class="productPrice">
                      <a class="madeInViewMore"  href="/games/<?php echo e($product->slug); ?>">  <h5><?php echo e('Details'); ?></h5></a>
                    </div>-->

                </div><!--client_logos-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





        </div>
    </div>
</div><!--client-->
<!-- =========================== End: Product Slider ========================= -->

<!-- Begin: BECOME A STERN INSIDER -->
<div class="becomeaSternInsider">
    <marquee attribute_name = "attribute_value"....more attributes>
        <a href="">EARLY ACCESS TO GAMES</a>
        <a href="">PRE-ORDER MERCH</a>
        <a href="">ACCESS TO STERN INSIDER EVENTS</a>
        <a href="">EXCLUSIVE MERCH</a>
        <a href="">BECOME A STERN INSIDER</a>
        <a href="">EARLY ACCESS TO GAMES</a>
        <a href="">PRE-ORDER MERCH</a>
        <a href="">ACCESS TO STERN INSIDER EVENTS</a>
        <a href="">EXCLUSIVE MERCH</a>
        <a href="">BECOME A STERN INSIDER</a>
    </marquee>
</div>
<!-- End: BECOME A STERN INSIDER -->


<!--================Begin: .becomeaSternInsiderBottom======== -->
<!-- <div class="becomeaSternInsiderBottom">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6">
                <div class="becomeaSternInsiderBottomBox">
                    <h3><span>BECOME A </span> <br> STERN INSIDER</h3>
                    <h5><a class="viewArticle" href="">View Article</a></h5>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!--================End: .becomeaSternInsider================= -->
<!--================Begin: articleSection======== -->
<div class="articleSection">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="articleBox">
                    <h3>THE 12 BEST PRODUCTS MADE IN AMERICA</h3>
                    <a class="madeInViewMore" href="">View Article</a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="articleBox">
                    <h3>FIFTY FACTORY TOURS THAT MAKE AMERICA GREAT</h3>
                    <a class="madeInViewMore" href="">View Article</a>
                </div>
            </div>

        </div>
    </div>

</div>
<!--================End: articleSection================= -->

<!--==============Begin: sternproCircuitTop============ -->
<!-- <div class="sternproCircuitTop">
    <div class="row">
        <div class="container-fluid">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <div class="topTeenText">
                    <h3>STERN PRO CIRCUIT <br>TOP 10 PLAYERS</h3>
                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="sternproCircuitTopText">
                    <marquee attribute_name = "attribute_value">
                        <a href="">1. BECOME A STERN INSIDER</a>
                        <a href="">2. BECOME A STERN INSIDER</a>
                        <a href="">3. BECOME A STERN INSIDER</a>
                        <a href="">4. BECOME A STERN INSIDER</a>
                        <a href="">5. BECOME A STERN INSIDER</a>
                        <a href="">6. BECOME A STERN INSIDER</a>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div> -->
<!--==============End: sternproCircuitTop============ -->
<!--==============Begin: sternproCircuitTop: Mobile ============ -->
<div class="sternproCircuitTopMobile">
    <div class="row">
        <div class="container-fluid">
            <div class="col-md-12 col-sm-3 col-xs-12">
                <div class="topTeenTextMobile">
                    <h3>STERN PRO CIRCUIT TOP 10 PLAYERS</h3>
                </div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-12">
                <div class="sternproCircuitTopTextMobile">
                    <marquee attribute_name = "attribute_value">
                        <a href="">1. BECOME A STERN INSIDER</a>
                        <a href="">2. BECOME A STERN INSIDER</a>
                        <a href="">3. BECOME A STERN INSIDER</a>
                        <a href="">4. BECOME A STERN INSIDER</a>
                        <a href="">5. BECOME A STERN INSIDER</a>
                        <a href="">6. BECOME A STERN INSIDER</a>
                    </marquee>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==============End: sternproCircuitTop Mobile============ -->





<!--==============Begin: Join us============ -->
<div class="joinUs">
    <div class="row">
        <div class="container-fluid">
            <div class="col-md-6 col-sm-6 col-xs-5">
            </div>
            <div class="col-md-6 col-sm-6 col-xs-7">
                <div class="joinusbox">
                    <h3>join us</h3>
                    <p>Find an event where you can play your favorite Stern Pinball machine–all over the world.</p>

                    <h5><a class="viewTrailer" href="">LEARN MORE</a></h5>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==============End: Join us============ -->
<!--==============Begin: Join us Mobile============ -->
<div class="joinUsMobile">
    <div class="row">
        <div class="container-fluidsss">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <img class="img-responsive image"   src="<?php echo e(asset('home_template/images/joinus-imge-mobile.jpg')); ?>" />
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="joinusboxMobile">
                    <h3>join us</h3>
                    <p>Find an event where you can play your favorite Stern Pinball machine–all over the world.</p>

                    <h5><a class="viewTrailer" href="">LEARN MORE</a></h5>
                </div>
            </div>
        </div>
    </div>
</div>
<!--==============End: Join us============ -->



<!-- Begin: Long live pin ball -->
<div class="longlivePinBall">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="lognLivePinballBox">
                    <div class="lognLivePinballBoxInner">
                        <h3>LONG LIVE PINBALL</h3>
                        <p>Stern Pinball, Inc. is a global lifestyle brand based on the iconic and outrageously fun modern American game of pinball.To learn more about our rich history, click the button below.</p>
                        <h5><a class="viewTrailer" href="">See History</a></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End: Long live pin ball -->
<?php /**PATH E:\laravel\sec\sec\resources\views/publicuser/content.blade.php ENDPATH**/ ?>